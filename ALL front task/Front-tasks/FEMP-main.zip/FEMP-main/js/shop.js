document.querySelector('#parametr').addEventListener('click',function(){
  document.querySelector('.s3-left').style.left = '0px'
})
document.querySelector('.closebtn i').addEventListener('click',function(){
  document.querySelector('.s3-left').style.left = '-330px'
})
